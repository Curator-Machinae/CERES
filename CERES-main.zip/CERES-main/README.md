# CERES
Cognitive Exoskeleton for Reasoning,  Execution, and Strategy (CERES) 
